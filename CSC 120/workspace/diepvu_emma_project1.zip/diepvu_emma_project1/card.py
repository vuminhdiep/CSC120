def card(rank, suit):
    """

    :param rank: rank of one card
    :param suit: suit of one card
    :return: one card with its rank and suit
    """
    one_card = {
        'Rank': rank,
        'Suit': suit,
    }
    return one_card
