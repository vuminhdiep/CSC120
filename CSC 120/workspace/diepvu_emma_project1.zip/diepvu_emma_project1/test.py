import random
"""
:return: a list of 52 shuffled cards and each card is a dict with rank and suit
"""
def create_deck():
    suits = ['C', 'D', 'H', 'S']
    rank = [str(i) for i in range(2, 11)]
    rank.extend(['J', 'Q', 'K', 'Ace'])
    deck_of_cards = []
    for suit in suits:
        for j in range(len(rank)):
            card = {}
            card['Rank'] = rank[j]
            card['Suit'] = suit
            deck_of_cards.append(card)
    random.shuffle(deck_of_cards)
    
    return (deck_of_cards)

"""
:param: deck of 52 cards
:return: a list of 10 cards as 2 hands
"""
def deal_cards(deck):
    hands = []
    for i in range(10):
        hands.append(deck[0])
        deck.pop(0)
 
    return hands

"""
:param: hands of cards
:return: check status if it's flush
"""

def check_flush(hands):
    switch = True

    for i in range(len(hands)-1):
        if hands[i]['Suit'] != hands[i + 1]['Suit']:
            switch = False
        else:
            switch = True
          
    return switch

"""
:param: hands of cards
:return: check if one pair or two pair and return the number of one pair or two pair
"""
def check_pair(hands):
    count_pair = 0
    copy_hands = []
    for hand in hands:
        copy_hands.append(hand)
    
    for i in range(len(copy_hands)-1):
        for j in range(i + 1, len(copy_hands)):
            if copy_hands[i]['Rank'] == copy_hands[j]["Rank"]:
                count_pair += 1
                delete1 = copy_hands[i]
                delete2 = copy_hands[j]
                copy_hands.remove(delete1)
                copy_hands.remove(delete2)
                break
    if count_pair > 0:
        for i in range(len(copy_hands) - 1):
            for j in range(i + 1, len(copy_hands)):
                if copy_hands[i]['Rank'] == copy_hands[j]["Rank"]:
                    count_pair += 1
                    delete1 = copy_hands[i]
                    delete2 = copy_hands[j]
                    copy_hands.remove(delete1)
                    copy_hands.remove(delete2)
                    break 
    return count_pair

"""
:return: the table output
"""
def main_program():
    res = {
        'Pair': 0,
        'Two-pairs': 0,
        'Flush': 0,
        'High-card': 0,

    }
    
    header = ['# of hands', 'pairs', '%', '2 pairs', '%', 'flushes', '%', 'high card', '%']
    print('%10s %11s %3s %13s %3s %12s %3s %14s %3s' % (tuple(header)))
    
    for i in range(10000):
        deck = create_deck()
        for k in range(5):
            hands = deal_cards(deck)
            for j in range(2):
                hand = hands[5 * j:5 * j + 5]
                
                if check_pair(hand) == 1:
                    res['Pair'] += 1
                elif check_pair(hand) == 2:
                    res['Two-pairs'] += 1
                else:
                    if check_flush(hand):
                        res['Flush'] += 1
                    else:
                        res['High-card'] += 1
        if (i + 1) % (1000) == 0:
            
            percent = {}

            
            for key in res.keys():
                percent[key] = res[key] / i / 10 * 100
            
                num_hands = (i + 1) * 10

            
            print('{:>10,} {:>11d} {:>05.2f} {:>11d} {:>05.2f} {:>10d} {:>05.2f} {:>12d} {:>05.2f}'
            .format(num_hands, res['Pair'], percent['Pair'],
             res['Two-pairs'], percent['Two-pairs'], res['Flush'],
             percent['Flush'], res['High-card'], percent['High-card']))


